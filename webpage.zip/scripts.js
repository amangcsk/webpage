document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('폼이 제출되었습니다!');
});